var config = {
  apiKey: "AIzaSyCStM8zTSkO-WZYVzdfPxsUe6srXCTZ0kU",
  authDomain: "bikcraft-269f9.firebaseapp.com",
  databaseURL: "https://bikcraft-269f9.firebaseio.com",
  projectId: "bikcraft-269f9",
  storageBucket: "bikcraft-269f9.appspot.com",
  messagingSenderId: "267753117411"
};
firebase.initializeApp(config);


